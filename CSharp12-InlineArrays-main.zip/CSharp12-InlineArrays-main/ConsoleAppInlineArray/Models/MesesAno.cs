﻿using System.Runtime.CompilerServices;

namespace ConsoleAppInlineArray.Models;

[InlineArray(length: 12)]
public struct MesesAno<T>
{
    private T _element0;
}