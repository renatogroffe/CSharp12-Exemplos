# CSharp12-InlineArrays
Exemplo em .NET 8 Preview 7 de Console Application criada com o C# 12 e que faz uso de Inline Array.
