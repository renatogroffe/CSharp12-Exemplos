# CSharp12-CollectionExpressions
Exemplo em .NET 8 Release Candidate 1 de Console Application criada com o C# 12 e que faz uso de Collection expressions.
